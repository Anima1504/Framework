package Mystepdef;

import DemoWebshop.Elements;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;

public class MyStepdefs {
    Elements el=new Elements();
    @Given("User succesfully adedd")
    public void userSuccesfullyAdedd() throws InterruptedException {
        el.element();
        el.webtables();

    }

    @Given("user able to click")
    public void userAbleToClick() throws InterruptedException {
        el.buttons();
    }

    @Given("User able to access")
    public void userAbleToAccess() throws InterruptedException {
        el.links();
    }
}
