package javapractices;

public class CompareNumbers {
    public static void main(String[] args){
        int num1=10,num2=10;

        if (num1==num2)
            System.out.println("Equl");

            else
                System.out.println("Not equal");


        }
    }

