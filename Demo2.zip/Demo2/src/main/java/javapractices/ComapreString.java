package javapractices;

public class ComapreString {
    public static void main(String[] args){
        String s1="Anima",s2="Anima";

        if (s1.equals(s2))
            System.out.println("Equl");

        else
            System.out.println("Not equal");


    }
}

