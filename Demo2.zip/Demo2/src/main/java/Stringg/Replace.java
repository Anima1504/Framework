package Stringg;

public class Replace {
    public static void main(String[] args) {
        String st1 = "Ani";
        String st2 = "tha";
        System.out.println("String: " + st1);
        System.out.println("String: " + st2);

        //Replace
        String S1=st1.replace('A','M');
        System.out.println("Replace: " + S1);
    }
}
