package Stringg;

public class SubString {
    public static void main(String[] args) {
        String st1 = "Anitha";
        System.out.println("String: " + st1);

        //Replace
        String S1 = st1.substring(2);
        System.out.println("Replace: " + S1);
    }
}
