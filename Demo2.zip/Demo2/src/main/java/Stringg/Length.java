package Stringg;


public class Length {
    public static void main(String[] args){
        String st="Anitha";
        System.out.println("String: "+st);

        //Length of a String
        int length=st.length();
        System.out.println("Length of string: "+length);


    }

}
