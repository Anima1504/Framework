package Stringg;

public class CharAtt {
    public static void main(String[] args) {
        String st1 = "Anima";
        System.out.println("String: " + st1);
        System.out.println(st1.charAt(3));
    }
}
