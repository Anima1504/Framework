package Stringg;

import java.util.Locale;

public class LowerUpper {
    public static void main(String[] args) {
        String st1 = "ANI";
        String st2 = "tha";
        System.out.println("String: " + st1);

        //To Lowercase
        String tolower= st1.toLowerCase();
        System.out.println("Lowercase: " + tolower);

        //To Upper
        String toupper= st1.toUpperCase();
        System.out.println("Uppercase: " + toupper);

    }
}
