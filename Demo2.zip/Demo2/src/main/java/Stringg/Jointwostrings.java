package Stringg;

public class Jointwostrings {
    public static void main(String[] args){
        String st1="Ani";
        String st2="tha";
        System.out.println("String: "+st1);
        System.out.println("String: "+st2);

        //Join 2 strings
        String joined=st1.concat(st2);
        System.out.println("String: "+joined);
    }
}
