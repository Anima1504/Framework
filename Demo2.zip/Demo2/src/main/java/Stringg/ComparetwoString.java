package Stringg;

public class ComparetwoString {
    public static void main(String[] args) {
        String st1 = "Ani";
        String st2 = "Anima";
        System.out.println("String: " + st1);
        System.out.println("String: " + st2);

        boolean compare = st1.equals(st2);
        System.out.println("String: " + compare);
    }
}