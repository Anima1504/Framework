package Stringg;

public class Startswith {
    public static void main(String[] args) {
        String st1 = "Anima";
        System.out.println("String: " + st1);
        System.out.println(st1.startsWith("A"));
        System.out.println(st1.endsWith("H"));

    }
}

